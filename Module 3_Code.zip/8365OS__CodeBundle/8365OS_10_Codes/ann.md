A portmanteau of "backward" and "propagation", backpropagation takes its name from the 

Backpropagation initializes all of the weights in the network to small random values that are typically between negative one and positive one.

After initialization, backpropagation alternates between a feedforward stage and a backpropagation stage. In the feedforward stage, a feature representation is input to the network. The hidden units receive the features, compute the activation potentials, and apply their activation functions. The outputs are received by the subsequent layer as usual, until the network computes a value for the response variable. 